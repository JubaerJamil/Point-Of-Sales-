<div id="loading-div" class="d-flex justify-content-center align-items-center d-none" style="margin-top: 300px";>
<button class="btn btn-primary" type="button" disabled>
    <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
    Loading...
  </button>
</div>
