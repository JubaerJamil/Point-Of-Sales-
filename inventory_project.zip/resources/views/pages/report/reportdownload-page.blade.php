@extends('layout.app')
@section('content')
        @include('components.report.report-download')
@endsection

