@extends('layout.app')
@section('content')
    @include('components.summary.dashboard-summary')
@endsection
