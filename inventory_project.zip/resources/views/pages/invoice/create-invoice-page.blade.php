@extends('layout.app');

@section('content')

    @include('components.invoice.create-sale')




@endsection
