@extends('layout.auth')
@section('content')
    @include('components.auth.send-otp-form')
@endsection
