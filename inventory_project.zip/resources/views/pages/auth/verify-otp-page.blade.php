@extends('layout.auth')
@section('content')
    @include('components.auth.verify-otp-form')
@endsection
