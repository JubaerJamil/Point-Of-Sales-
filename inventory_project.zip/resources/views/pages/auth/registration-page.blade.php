@extends('layout.auth')

@section('content')
    @include('components.auth.registration-form')
@endsection
