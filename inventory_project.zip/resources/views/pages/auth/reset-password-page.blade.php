@extends('layout.auth')
@section('content')
    @include('components.auth.reset-password-form')
@endsection
