@extends('layout.auth')
@section('content')
    @include('components.auth.login-form')
@endsection
